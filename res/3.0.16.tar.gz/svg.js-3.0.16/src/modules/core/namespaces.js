// Default namespaces
export const ns = 'http://www.w3.org/2000/svg'
export const xmlns = 'http://www.w3.org/2000/xmlns/'
export const xlink = 'http://www.w3.org/1999/xlink'
export const svgjs = 'http://svgjs.com/svgjs'
